const demoUsers = [
  { email: "user@example.com", password: "user123", role: "user" },
  { email: "agent@example.com", password: "agent123", role: "agent" },
  { email: "admin@example.com", password: "admin123", role: "admin" }
];

document.addEventListener("DOMContentLoaded", function () {
  const loginForm = document.querySelector("form.login-form");

  if (loginForm && location.pathname.includes("login")) {
    loginForm.addEventListener("submit", function (e) {
      e.preventDefault(); // stop form from reloading

      const email = loginForm.querySelector('input[type="email"]').value.trim();
      const password = loginForm.querySelector('input[type="password"]').value.trim();

      const user = demoUsers.find(u => u.email === email && u.password === password);

      if (user) {
        alert(`Welcome, ${user.role}!`);
        if (user.role === "user") window.location.href = "dashboard.html";
        else if (user.role === "agent") window.location.href = "agent-dashboard.html";
        else if (user.role === "admin") window.location.href = "admin-dashboard.html";
      } else {
        alert("Invalid email or password.");
      }
    });
  }
});
